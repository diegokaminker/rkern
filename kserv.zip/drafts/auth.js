const jwt = require('jsonwebtoken');
const express = require('express');
const bearerToken = require('express-bearer-token');
const app = express();
const secretKey = "secretapikey";
app.use(bearerToken());
app.use(function(req, res) {
    token = req.token;
    var decoded = jwt.decode(token, { complete: true });
    var user = {
        username: decoded.payload.username,
        "clinical-scope": "user/*,*",
        sub: "Hospital de Buenos Aires",
        aud: "http://localhost:3000/4_0_0",
        iss: "https://hospitaldebuenosaires.org/fhir",
    };
    signedToken = jwt.sign(user, secretKey);
    res.send(signedToken);
});
app.listen(3001);