const jwt = require('jsonwebtoken');
const accessTokenSecret = 'youraccesstokensecret';
const accessToken = jwt.sign(

    {
        "username": "Hospital De Buenos Aires",
        "clinical-scope": 'user/*,*',
        "sub": "Hospital de Buenos Aires",
        "aud": "http://localhost:3000/4_0_0",
        "iss": "https://hospitaldebuenosaires.org/fhir",

    }

    , accessTokenSecret);
console.log(accessToken);