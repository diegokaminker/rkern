var htmlIn = '*fo:external-graphic src=" \\\\srvrdapps\\Content\\Logos\\logo_DL.png" content-height="scale-down-to-fit" height="1.5cm" width="4.5cm" fo:external-graphic*'
var aux = "";
aux = htmlIn;
aux = aux.replace("*fo:external-graphic", '{"graphic":{');
aux = aux.replace("fo:external-graphic*", "}}");
aux = aux.replace('content-height=', ',"content-height":');
aux = aux.replace('height=', ',"height":');
aux = aux.replace('width=', ',"width":');
aux = aux.replace(/\\/g, "\\\\");
aux = aux.replace('src=', '"src":');
console.log(aux);
jconfig = JSON.parse(aux);
FullName = jconfig.graphic.src;
path = FullName.split("\\");
console.log(path);
RealPath = path[path.length - 1];
console.log(RealPath);