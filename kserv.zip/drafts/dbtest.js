Sequelize=require('sequelize');
const sequelize = new Sequelize('patient', 'postgres', '1972', {
  dialect: 'postgres'
})

const FHIR_Patient = sequelize.define('FHIR_Patient', {
  family: {
    field: 'pat_family',
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null
  },
  given: {
    field: 'pat_given',
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null
  },
  birthdate:
  {
    field: 'dob',
    type: Sequelize.DATE,
    allowNull: true,
    defaultValue: null
  },
  gender:
  {
    field: 'pat_given',
    type: Sequelize.STRING,
    allowNull: true,
    defaultValue: null
  },
  id:
  {
    field:'patient_id',
    type: Sequelize.BIGINT,
    primaryKey: true,
    allowNull: false,
    defaultValue: null,
    
  }
});
sequelize.query("SELECT * FROM patient;", 
{ type: sequelize.QueryTypes.SELECT,model:FHIR_Patient,mapToModel:true}
).then(paciente => {
      console.log(JSON.stringify(paciente));
    // We don't need spread here, since only the results will be returned for select queries
  })