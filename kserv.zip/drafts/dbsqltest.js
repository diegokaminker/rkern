Sequelize=require('sequelize');

const sequelize = new Sequelize('KERN_LIS_PLUS', 'quazar', 'quazar', 
{
  host:  '190.7.57.170',
  dialect: 'mssql',
  dialectOptions: {
    options: {
      useUTC: false,
      dateFirst: 1,
      enableArithAbort: true  
    }
  }
})

sequelize.query("SELECT * FROM paciente", { type: sequelize.QueryTypes.SELECT})
  .then(paciente => {
      console.log(JSON.stringify(paciente));
    // We don't need spread here, since only the results will be returned for select queries
  })