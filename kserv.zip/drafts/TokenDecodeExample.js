const jwt = require('jsonwebtoken');
const accessTokenSecret = 'youraccesstokensecret';

const accessToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6Ikhvc3BpdGFsIEFsZW1hbiIsImNsaW5pY2FsLXNjb3BlIjoidXNlci8qLCoiLCJzdWIiOiJIb3NwaXRhbCBBbGVtYW4gZGUgQnVlbm9zIEFpcmVzIiwiYXVkIjoiaHR0cDovL2xvY2FsaG9zdDozMDAwLzRfMF8wIiwiaXNzIjoiaHR0cHM6Ly9ob3NwaXRhbGFsZW1hbi5vcmcvZmhpciIsImlhdCI6MTU4MzkzNjA1MX0.Mvflv3oTVQp5KSUmsFkra_rdwEVTVfxCuEKfRiosuHo';
console.log(accessToken);
console.log(accessTokenSecret);
var decoded = jwt.decode(accessToken, { complete: true });
console.log(decoded.header);
console.log(decoded.payload);