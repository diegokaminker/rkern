/*eslint no-unused-vars: "warn"*/
Sequelize = require('sequelize');
const uuidv4 = require('uuid/v4');
const sequelize = require('./dbconfig.js').db;
const { RESOURCES } = require('@asymmetrik/node-fhir-server-core').constants;
const FHIRServer = require('@asymmetrik/node-fhir-server-core');
const getParameters = require('@asymmetrik/node-fhir-server-core/src/server/resources/4_0_0/schemas/parameters');
const getBundleEntry = require('@asymmetrik/node-fhir-server-core/src/server/resources/4_0_0/schemas/bundleentry');
const getBundle= require('@asymmetrik/node-fhir-server-core/src/server/resources/4_0_0/schemas/bundle');
const getCodeSystem = require('@asymmetrik/node-fhir-server-core/src/server/resources/4_0_0/schemas/codesystem');
const { urlbase } = require('./config.js');
let getMeta = (base_version) => {
    return require(FHIRServer.resolveFromVersion(base_version, RESOURCES.META));
};

module.exports.search = (args, context, logger) => new Promise((resolve, reject) => {

    // Common search params
    let { base_version, _content, _format, _id, _lastUpdated, _profile, _query, _security, _tag } = args;

    // Search Result params
    let { _INCLUDE, _REVINCLUDE, _SORT, _COUNT, _SUMMARY, _ELEMENTS, _CONTAINED, _CONTAINEDTYPED } = args;

    let url = args['url'];
    var sp = require('./spconfig.js').sp;

    
    query = sp('CodeSystemBuscarPorURL'),
        params = {
            replacements: { qurl: url },
            type: sequelize.QueryTypes.SELECT
        }

    // TODO: Query database
    sequelize.query(query, params).then(
        data => {

            var result = [];
            let BundleEntry = getBundleEntry;
            let Bundle = getBundle;
            let CodeSystem = getCodeSystem;
            
            concepts=[];    
            data.forEach(record => {
                concepts.push
                (
                    {
                      "code": record.CODIGO,
                      "display": record.DESCRIPCION
                    });
                
               
            });
            cs = new CodeSystem();
            cs.id=url;
            cs.text={
                "status": "empty",
                "div": "<div xmlns=\"http://www.w3.org/1999/xhtml\"></div>"
              };
            cs.url=url;
            cs.status= "active";
            cs.date=  new Date();
            cs.concept=concepts ;
            let entries = [
                new BundleEntry({
                    fullUrl:  url,
                    resource: cs
                })];

            let bundle = new Bundle({
                id: uuidv4(),
                meta: {
                    lastUpdated: new Date()
                },
                type: "searchset",
                total: entries.length,
                entry: entries
            });
            resolve(bundle);

        }
    )

});

module.exports.lookup = (args, context, logger) => new Promise((resolve, reject) => {
    // Common search params
    let { base_version, _content, _format, _id, _lastUpdated, _profile, _query, _security, _tag } = args;
    // Search Result params
    let { _INCLUDE, _REVINCLUDE, _SORT, _COUNT, _SUMMARY, _ELEMENTS, _CONTAINED, _CONTAINEDTYPED } = args;

    var sp = require('./spconfig.js').sp;
    let code = args['code'];
    let system = args['system'];
    var query = '';
    var params = '';
    // Resource Specific params
    //SPECIMEN_TYPE
    if (system == 'http://labdl.com.ar/codesystems/specimen_type') {
        query = sp('TipoMuestraBuscarPorCodigo');
        params = {
            replacements: { cod: code },
            type: sequelize.QueryTypes.SELECT
        };
    }
    //BODY_SITE_DESCRIPTION

    if (system == 'http://labdl.com.ar/codesystems/body_site_description') {
        query = sp('OrigenMuestraBuscarPorCodigo');
        params = {
            replacements: { cod: code },
            type: sequelize.QueryTypes.SELECT
        };
        console.log(query);
    }



    //PROCEDURE_DEFINITION

    if (system == 'http://labdl.com.ar/codesystems/procedure_definition') {
        query = sp('PrestacionBuscarPorCodigo');
        params = {
            replacements: { cod: code },
            type: sequelize.QueryTypes.SELECT
        };
    }

    // TODO: Query database
    sequelize.query(query, params).then(
        result => {
            let R = new getParameters();
            let record = result[0];
            R.parameter = [{
                name: "display",
                valueString: record.DESCRIPCION
            }];
            console.log(R);
            resolve(R);

        }
    )

});