/*eslint no-unused-vars: "warn"*/
Sequelize = require('sequelize');
const uuidv4 = require('uuid/v4');
const sequelize = require('./dbconfig.js').db;
const sp = require('./spconfig.js').sp;
const { RESOURCES } = require('@asymmetrik/node-fhir-server-core').constants;
const FHIRServer = require('@asymmetrik/node-fhir-server-core');
const getRequestGroup = require('@asymmetrik/node-fhir-server-core/src/server/resources/4_0_0/schemas/requestgroup');
const getBundleEntry = require('@asymmetrik/node-fhir-server-core/src/server/resources/4_0_0/schemas/bundleentry');
const getBundle = require('@asymmetrik/node-fhir-server-core/src/server/resources/4_0_0/schemas/bundle');
const urlbase = require('./config.js').urlbase;
let getMeta = (base_version) => {
    return require(FHIRServer.resolveFromVersion(base_version, RESOURCES.META));
};

module.exports.activate = (args, context, logger) => new Promise((resolve, reject) => {
    // Common search params
    let { base_version, _content, _format, _id, _lastUpdated, _profile, _query, _security, _tag } = args;
    // Search Result params
    let { _INCLUDE, _REVINCLUDE, _SORT, _COUNT, _SUMMARY, _ELEMENTS, _CONTAINED, _CONTAINEDTYPED } = args;

    var sp = require('./spconfig.js').sp;
    resource = context.req.body;
    let rg = resource;
    console.log(JSON.stringify(rg));
    rg.parameter.forEach(par => {
        switch (par.name) {
            case "draftRequest":
                ident = par.valueReference.reference;
                break;
            case "location":
                locat = par.valueCode;
            default:
                break;
        }

    }
    );

    var query = '';
    var params = '';
    query = sp('OrdenActivar'),
        params = {
            replacements: { iden: ident, loca: locat },
            type: sequelize.QueryTypes.SELECT
        }
    // TODO: Query database
    request = {};
    sequelize.query(query, params).then(

        data => {
            console.log(JSON.stringify(data));
            var id = data[0].RESULTADO;
            var msg = data[0].MENSAJE;
            if (id == 0) {
                response = {
                    "resourceType": "Parameters",
                    "parameter":
                        [{
                            "name": "error",
                            "valueString": msg
                        }
                        ]
                }

            }
            else {
                response = {
                    "resourceType": "Parameters",
                    "parameter":
                        [{
                            "name": "activeRequest",
                            "valueReference": { "reference": "RequestGroup/" + id.toString() }
                        }]
                }
            }

            resolve(response);

        });




});

module.exports.search = (args, context, logger) => new Promise((resolve, reject) => {


    // Common search params
    let { base_version, _content, _format, _id, _lastUpdated, _profile, _query, _security, _tag } = args;

    // Search Result params
    let { _INCLUDE, _REVINCLUDE, _SORT, _COUNT, _SUMMARY, _ELEMENTS, _CONTAINED, _CONTAINEDTYPED } = args;

    let baseUrl = GetBaseUrl(context);
    let MyStatus = args['status'];
    let MyPatient = args['patient'];
    let MyQuery = args['_query'];
    if (!MyStatus) { MyStatus = '' }
    if (MyQuery) {
        if (MyQuery == "manual_edit") {
            let lastUpd= args['_lastUpdated'];
            if (!lastUpd)
            {
                lastUpd="ge"+Date.toString();
            }
            
            query = sp('OrdenesListarModificadasManualmente'),
                params = {
                    replacements: { lup: lastUpd },
                    type: sequelize.QueryTypes.SELECT
                }
        }

    }
    if (MyPatient) {
        query = sp('OrdenesListarPorPacienteEstado'),
            params = {
                replacements: { sta: MyStatus, pat: MyPatient },
                type: sequelize.QueryTypes.SELECT
            }

    }
    // TODO: Query database
    sequelize.query(query, params).then(
        data => {

            //TRAE UN SOLO REGISTRO	
            var result = [];
            let BundleEntry = getBundleEntry;
            let Bundle = getBundle;
            data.forEach(record => {
                let R = new getRequestGroup();

                R.id = record.PEDIDO_ID;
                R.authoredOn = record.FECHA_PEDIDO;
                R.identifier =
                    [
                        {
                            system: urlbase + "/orden_id_lis",
                            value: record.PEDIDO
                        }
                    ];
                if (MyQuery)
                {R.status = record.STATUS}
                else
                {
                    R.status = MyStatus;
                    var ext = {
                        url: urlbase + "/fhir/StructureDefinition/estado_extendido",
                        valueString: record.STATUS
                    };
                    R.extension = [ext];
                
                };
                R.intent = 'order';
                R.code = {
                    coding: [{
                        system: "http://loinc.org",
                        code: "18842-5"
                    }]
                };

                if (record.URL_REPORTE != '') {
                    R.action =
                    [
                        {
                            "title": "Ver Reporte",
                            "resource": { "reference": baseUrl + 'DiagnosticReport/' + record.URL_REPORTE }
                        }
                    ];
                };
                R.note = [{ text: record.PRESTACIONES }];
                if (record.FECHA_HORA)
                {
                    R.meta={lastUpdated : record.FECHA_HORA};
                }
                result.push(R);
            });

            let entries = result.map(reportgroup =>
                new BundleEntry({
                    fullUrl: baseUrl + 'ReportGroup/' + reportgroup.id,
                    resource: reportgroup
                }));
            let bundle = new Bundle({
                id: uuidv4(),
                meta: {
                    lastUpdated: new Date()
                },
                type: "searchset",
                total: entries.length,
                entry: entries
            });
            resolve(bundle);

        }
    )

});


function GetBaseUrl(context) {
    var baseUrl = "";
    const FHIRVersion = "/4_0_0/";
    var protocol = "http://";
    if (context.req.secure) { protocol = "https://"; }
    baseUrl = protocol + context.req.headers.host + FHIRVersion;
    return baseUrl;

};

module.exports.searchById = (args, context, logger) => new Promise((resolve, reject) => {
    // logger.info('RequestGroup >>> searchById');

    let { base_version, id } = args;

    let RequestGroup = getRequestGroup(base_version);

    // TODO: Build query from Parameters

    // TODO: Query database

    // Cast result to RequestGroup Class
    let requestgroup_resource = new RequestGroup();
    // TODO: Set data with constructor or setter methods
    requestgroup_resource.id = 'test id';

    // Return resource class
    // resolve(requestgroup_resource);
    resolve();
});

module.exports.create = (args, context, logger) => new Promise((resolve, reject) => {
    //  logger.info('RequestGroup >>> create');
    let { base_version, id, resource } = args;
    resource = context.req.body;
    //console.log('context');
    //console.log(context.req);
    //let Meta = getMeta(base_version);

    // TODO: determine if client/server sets ID

    // Cast resource to RequestGroup Class
    let rg = resource;

    var pat = null;
    var enc = null;
    var pra = null;
    var cov = null;
    // TODO: set meta info
    //Header
    //
    console.log("About to enter forEach resource");

    rg.contained.forEach(resource => {

        switch (resource.resourceType) {

            case "Patient":
                pat = resource;
                break;
            case "Encounter":
                enc = resource;
                break;
            case "Practitioner":
                pra = resource;
                break;
            case "Coverage":
                cov = resource;
                break;
            case "DocumentReference":
                doc = resource;
            default:
                break;
        }
    }
    );

    var act = [];

    rg.action.forEach(action => {
        act.push(action);
    });
    var orderHeader = [];
    var orderItems = [];
    console.log("Phase #1");
    //Extraer totales de la extension http://labdl.com.ar/fhir/StructureDefinition/financial
    if (rg.extension) {
        rg.extension.forEach(ext => {
            switch (ext.url) {
                case "http://labdl.com.ar/fhir/StructureDefinition/horario_guardia":
                    orderHeader.push({ item: { clave: "order-emergency-flag", valor: ext.valueBoolean } });
                    break;
                case "http://labdl.com.ar/fhir/StructureDefinition/financial":
                    ext.extension.forEach(subExt => {
                        switch (subExt.url) {
                            case "TotalAmount":
                                orderHeader.push({ item: { clave: "order-TotalAmount", valor: subExt.valueMoney.value } });
                                break;
                            case "PatientAmount":
                                orderHeader.push({ item: { clave: "order-PatientAmount", valor: subExt.valueMoney.value } });

                                break;
                            case "IVAAmount":
                                orderHeader.push({ item: { clave: "order-IVAAmount", valor: subExt.valueMoney.value } });

                                break;
                            default:
                                break;
                        }
                    });
            }
        });
    }
    console.log("Phase #2");
    //Datos Generales de la Orden: números
    rg.identifier.forEach(
        rgi => {
            console.log("system");
            console.log(rgi.system);
            switch (rgi.system) {
                case "http:/hospitalaleman.com.ar/comprobantes":
                    orderHeader.push({ item: { clave: "order-Identifier", valor: rgi.value } });
                    break;
                case "http:/hospitalaleman.com.ar/pedidos":
                    orderHeader.push({ item: { clave: "order-alt-Identifier", valor: rgi.value } });
                    break;
                case "http:/hospitalaleman.com.ar/vales":
                    orderHeader.push({ item: { clave: "order-adm-Identifier", valor: rgi.value } });
                    break;
                default:
                    break;
            }
        }
    );


    orderHeader.push({ item: { clave: "order-PrescriptionDate", valor: rg.authoredOn } });
    //Lo maximo que aceptamos es dos codigos de diagnostico
    //codificados y uno (aparte) libre
    re = 0;
    rf = 0;
    if (rg.reasonCode) {
        rg.reasonCode.forEach(
            rea => {
                re = re + 1;
                if (rea.coding) {
                    if (re <= 2) {
                        orderHeader.push({ item: { clave: "order-reason-coded-" + re.toString(), valor: rea.coding[0].code } });
                    }
                } else
                    if (rea.text) {
                        rf = rf + 1;
                        if (rf == 1) { orderHeader.push({ item: { clave: "order-reason-free-" + re.toString(), valor: rea.text } }) };

                    }
            });
    }
    if (rg.note) {
        console.log("nota box");
        orderHeader.push({ item: { clave: "order-message-box", valor: rg.note[0].text } });
    }
    console.log("Phase #3a");
    //Medico Solicitante ('Practitioner')
    orderHeader.push({ item: { clave: "doctor-id", valor: pra.identifier[0].value } });
    orderHeader.push({ item: { clave: "doctor-family", valor: pra.name[0].family } });
    orderHeader.push({ item: { clave: "doctor-given", valor: pra.name[0].given[0] } });
    orderHeader.push({ item: { clave: "doctor-prefix", valor: pra.name[0].prefix } });
    console.log("Phase #3b");
    orderHeader.push({ item: { clave: "doctor-phone", valor: pra.telecom[0].value } });
    orderHeader.push({ item: { clave: "doctor-email", valor: pra.telecom[1].value } });
    orderHeader.push({ item: { clave: "doctor-address", valor: pra.address[0].line[0] } });
    orderHeader.push({ item: { clave: "doctor-city", valor: pra.address[0].city } });
    orderHeader.push({ item: { clave: "doctor-postalcode", valor: pra.address[0].postalCode } });

    if (pra.qualification) {
        orderHeader.push({ item: { clave: "doctor-specialty", valor: pra.qualification[0].code.coding[0].code } })
    };
    //Cobertura ('Coverage')
    console.log("Phase #4");
    console.log(JSON.stringify(cov));
    console.log("num");
    orderHeader.push({ item: { clave: "coverage-number", valor: cov.identifier[0].value } });
    console.log("payor");
    orderHeader.push({ item: { clave: "coverage-payor", valor: cov.payor[0].identifier.value } });
    console.log("plan");
    orderHeader.push({ item: { clave: "coverage-plan", valor: cov.contract[0].identifier.value } });
    console.log("tax");
    var ttax = cov.class[0].value;
    if (!(ttax)) { ttax = "V" };
    orderHeader.push({ item: { clave: "coverage-tax", valor: ttax } });
    //Paciente  ('Patient')
    console.log("Phase #5");

    orderHeader.push({ item: { clave: "patient-identifier_ext", valor: pat.identifier[0].system + "|" + pat.identifier[0].value } });
    if (pat.identifier[1]) {
        orderHeader.push({ item: { clave: "patient-identifier_int", valor: pat.identifier[1].system + "|" + pat.identifier[1].value } });
    }
    if (pat.identifier[2]) {
        orderHeader.push({ item: { clave: "patient-identifier_nat", valor: pat.identifier[2].system + "|" + pat.identifier[2].value } });
    }
    if (pat.identifier[3]) {
        orderHeader.push({ item: { clave: "patient-identifier_otr", valor: pat.identifier[3].system + "|" + pat.identifier[3].value } });
    }
    if (pat.identifier[4]) {
        orderHeader.push({ item: { clave: "patient-identifier_otn", valor: pat.identifier[4].system + "|" + pat.identifier[4].value } });
    }

    console.log("Phase #5b");
    orderHeader.push({ item: { clave: "patient-family", valor: pat.name[0].family } });
    orderHeader.push({ item: { clave: "patient-given", valor: pat.name[0].given[0] } });
    console.log("Phase #5c");
    orderHeader.push({ item: { clave: "patient-gender", valor: pat.gender } });
    orderHeader.push({ item: { clave: "patient-birth_date", valor: pat.birthDate } });
    if (pat.address[0]) {
        console.log("Phase #5d1");
        orderHeader.push({ item: { clave: "patient-address", valor: pat.address[0].line[0] } });
        console.log("Phase #5d2");
        orderHeader.push({ item: { clave: "patient-postalcode", valor: pat.address[0].postalCode } });
        console.log("Phase #5d3");
        orderHeader.push({ item: { clave: "patient-city", valor: pat.address[0].city } });
    }
    console.log("Phase #5e");
    //Números de telefono y direcciones de email
    ph = 0;
    em = 0;
    pat.telecom.forEach(tel => {
        if (tel.system == "phone") {
            ph = ph + 1;
            orderHeader.push({ item: { clave: "patient-phone-" + ph.toString(), valor: tel.value } });
        } else {
            em = em + 1;
            orderHeader.push({ item: { clave: "patient-email-" + em.toString(), valor: tel.value } });
        }

    });


    console.log("Phase #6");
    if (pat.extension) {
        pat.extension.forEach(ext => {
            switch (ext.url) {
                case "http://kern-it.com.ar/fhir/StructureDefinition/nota":
                    orderHeader.push({ item: { clave: "patient.note", valor: ext.valueString } });
                    break;
                case "http://kern-it.com.ar/fhir/StructureDefinition/autorizaciones":
                    ext.extension.forEach(subExt => {
                        switch (subExt.url) {
                            case "#graba_web":
                                orderHeader.push({ item: { clave: "patient-graba_web", valor: subExt.valueBoolean } });
                                break;
                            case "#envio_mail":
                                orderHeader.push({ item: { clave: "patient-envio_mail", valor: subExt.valueBoolean } });

                                break;
                            case "#uso_academico":
                                orderHeader.push({ item: { clave: "patient-uso_academico", valor: subExt.valueBoolean } });

                                break;
                            default:
                                break;
                        }
                    });
            }
        });
    }
    console.log("Phase #7");

    //Episodio ('Encounter')
    if (enc.identifier) {
        orderHeader.push({ item: { clave: "encounter-identifier", valor: enc.identifier[0].value } });
    }
    orderHeader.push({ item: { clave: "encounter-class", valor: enc.class.code } });
    if (enc.period) {
        orderHeader.push({ item: { clave: "encounter-begin", valor: enc.period.start } });
    }
    enc.location.forEach(loc => {
        switch (loc.physicalType.coding[0].code) {
            case "wd":
                orderHeader.push({ item: { clave: "encounter-location", valor: loc.location.identifier.value } });
                break;
            case "ro":
                orderHeader.push({ item: { clave: "encounter-room", valor: loc.location.identifier.value } });
                break;
            case "bd":
                orderHeader.push({ item: { clave: "encounter-bed", valor: loc.location.identifier.value } });
                break;
        }
    });
    if (enc.serviceType) {
        orderHeader.push({ item: { clave: "encounter-service", valor: enc.serviceType.value } });
    }
    //Procesa items de la orden
    console.log("Phase #8a");

    act.forEach(action => {
        orderItems.push({ item: { row: row, clave: "row", valor: action.prefix } });
        var row = action.prefix;
        console.log("Phase #8b");

        orderItems.push({ item: { row: row, clave: "priority", valor: action.priority } });
        console.log("Phase #8c");

        orderItems.push({ item: { row: row, clave: "code", valor: action.code[0].coding[0].code } });
        console.log("Phase #8d");

        orderItems.push({ item: { row: row, clave: "date", valor: action.timingDateTime } });
        console.log("Phase #8e");
        console.log(JSON.stringify(action));
        orderItems.push({ item: { row: row, clave: "action", valor: action.type.coding.code } });
        console.log("Phase #8f");

        if (action.extension) {
            action.extension.forEach(ext => {
                switch (ext.url) {
                    case "http://kern-it.com.ar/fhir/StructureDefinition/flags_orden":
                        ext.extension.forEach(subExt => {
                            switch (subExt.url) {
                                case "#realizar":
                                    orderItems.push({ item: { row: row, clave: "realizar", valor: subExt.valueBoolean } });
                                    break;
                                case "#facturar":
                                    orderItems.push({ item: { row: row, clave: "facturar", valor: subExt.valueBoolean } });
                                    break;
                                case "#debe_muestra":
                                    orderItems.push({ item: { row: row, clave: "debe_muestra", valor: subExt.valueBoolean } });
                                    break;
                                default:
                                    break;
                            }

                        });
                        break;
                    case "http://labdl.com.ar/fhir/StructureDefinition/financial":
                        ext.extension.forEach(subExt => {
                            console.log(subExt.url);
                            switch (subExt.url) {
                                case "#HMOPrice":
                                    orderItems.push({ item: { row: row, clave: "HMOPrice", valor: subExt.valueMoney.value } });
                                    break;
                                case "#PatientAmount":
                                    orderItems.push({ item: { row: row, clave: "PatientAmount", valor: subExt.valueMoney.value } });
                                    break;
                                case "#LabFixedPrice":
                                    orderItems.push({ item: { row: row, clave: "LabFixedPrice", valor: subExt.valueMoney.value } });
                                    break;
                                case "#LabPercentage":
                                    orderItems.push({ item: { row: row, clave: "LabPercentage", valor: subExt.valueDecimal } });
                                    break;
                                default:
                                    break;
                            }

                        });
                        break;
                    case "http://kern-it.com.ar/fhir/StructureDefinition/cantidad_prestaciones":
                        orderItems.push({ item: { row: row, clave: "cantidad", valor: ext.extension[0].valueInteger } });
                        break;
                    case "http://kern-it.com.ar/fhir/StructureDefinition/fecha_entrega":
                        orderItems.push({ item: { row: row, clave: "fecha_entrega", valor: ext.valueDate } });
                        break;
                    case "http://kern-it.com.ar/fhir/StructureDefinition/tipo_muestra":
                        ext.extension.forEach(subExt => {
                            switch (subExt.url) {
                                case "#SpecimenType":
                                    orderItems.push({ item: { row: row, clave: "sample-specimentype", valor: subExt.valueCoding.code } });
                                    break;
                                case "#BodySite":
                                    orderItems.push({ item: { row: row, clave: "sample-bodysite", valor: subExt.valueCoding.code } });
                                    break;
                                case "#Description":
                                    orderItems.push({ item: { row: row, clave: "sample-description", valor: subExt.valueString } });
                                    break;
                                default:
                                    break;
                            }

                        });

                        break;
                    default:
                        break;

                }

            })
        }
    });
    // if (doc)
    // {
    //     orderHeader.push({ item: { clave: "order-url", valor: doc.content[0].attachment.url } });
    // }
    console.log("Phase #9");

    var xml2js = require('xml2js');
    var builder = new xml2js.Builder();
    var xmlHea = builder.buildObject(orderHeader);
    var xmlIte = builder.buildObject(orderItems);

    //Details
    query = sp("OrdenAgregar");
    param = {
        replacements: { hea: xmlHea, ite: xmlIte },
        type: sequelize.QueryTypes.SELECT
    }
    sequelize.query(query, param).then(
        data => {
            console.log(JSON.stringify(data));
            resolve({ id: data[0].ID });
        });


    // Return Id

});

module.exports.update = (args, context, logger) => new Promise((resolve, reject) => {
    logger.info('RequestGroup >>> update');

    let { base_version, id, resource } = args;

    let RequestGroup = getRequestGroup(base_version);
    let Meta = getMeta(base_version);

    // Cast resource to RequestGroup Class
    let requestgroup_resource = new RequestGroup(resource);
    requestgroup_resource.meta = new Meta();
    // TODO: set meta info, increment meta ID

    // TODO: save record to database

    // Return id, if recorded was created or updated, new meta version id
    resolve({ id: requestgroup_resource.id, created: false, resource_version: requestgroup_resource.meta.versionId });
});