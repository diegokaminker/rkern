/*eslint no-unused-vars: "warn"*/
/*VERSION 2021-07-26T120700*/
Sequelize = require('sequelize');
var buffer = require('buffer');
var dateformat = require('dateformat');
var path = require('path');
const Entities = require('html-entities').AllHtmlEntities;
const entities = new Entities();
var fs = require('fs');
const uuidv4 = require('uuid/v4');
const sequelize = require('./dbconfig.js').db;
const sp = require('./spconfig.js').sp;
const { RESOURCES } = require('@asymmetrik/node-fhir-server-core').constants;
const FHIRServer = require('@asymmetrik/node-fhir-server-core');
const getDiagnosticReport = require('@asymmetrik/node-fhir-server-core/src/server/resources/4_0_0/schemas/diagnosticreport');
const getRequestGroup = require('@asymmetrik/node-fhir-server-core/src/server/resources/4_0_0/schemas/requestgroup');
const getObservation = require('@asymmetrik/node-fhir-server-core/src/server/resources/4_0_0/schemas/observation');
const getEncounter = require('@asymmetrik/node-fhir-server-core/src/server/resources/4_0_0/schemas/encounter');
const getBundle = require('@asymmetrik/node-fhir-server-core/src/server/resources/4_0_0/schemas/bundle');
const getBundleEntry = require('@asymmetrik/node-fhir-server-core/src/server/resources/4_0_0/schemas/bundleentry');
const getSpecimen = require('@asymmetrik/node-fhir-server-core/src/server/resources/4_0_0/schemas/specimen');
const urlbase  = require('./config.js').urlbase;
let getMeta = (base_version) => {
    return require(FHIRServer.resolveFromVersion(base_version, RESOURCES.META));
};

module.exports.search = (args, context, logger) => new Promise((resolve, reject) => {
    //	logger.info('DiagnosticReport >>> search');

    // Common search params
    let { base_version, _content, _format, _id, _lastUpdated, _profile, _query, _security, _tag } = args;

    // Search Result params
    let { _INCLUDE, _REVINCLUDE, _SORT, _COUNT, _SUMMARY, _ELEMENTS, _CONTAINED, _CONTAINEDTYPED } = args;

    let baseUrl = GetBaseUrl(context);
    let lastUpdated = args['_lastUpdated'];
    let status='final,preliminary';
    let MyStatus = args['status'];
    let MyPatient = args['patient'];
    let MyIdentifier=args['identifier'];
    if ( MyStatus ){status=MyStatus;}
    
    // Resource Specific params
    console.log("lastUpdated",lastUpdated);
    if (MyIdentifier)
    {
        query = sp('ReportesListarPorIdentificador'),
        params = {
            replacements: {  sta: status,ide:MyIdentifier },
            type: sequelize.QueryTypes.SELECT
        }
    }
    else
    {
    if (MyPatient)
    {
        query = sp('ReportesListarPorEstadoFechaActualizacionPaciente'),
        params = {
            replacements: { lup: lastUpdated, sta: status,pat:MyPatient },
            type: sequelize.QueryTypes.SELECT
        }
    }
    else
    {
        query = sp('ReportesListarPorEstadoFechaActualizacion'),
        params = {
            replacements: { lup: lastUpdated, sta: status },
            type: sequelize.QueryTypes.SELECT
        }
    }
    }
    // TODO: Query database
    sequelize.query(query, params).then(
        data => {

            //TRAE UN SOLO REGISTRO	
            var result = [];
            let BundleEntry = getBundleEntry;
            let Bundle = getBundle;
            data.forEach(record =>
             {
                let R = new getDiagnosticReport();

                R.id = record.ID;
                R.issued = record.FECHA;
                R.identifier = 
                [
                    {
                    system: urlbase+'/diag_rep_id',
                    value: record.ID
                    }
                ];
                R.basedOn =
                [{
                    identifier:{
                    system: urlbase+ '/orden_id_lis',
                    value: record.PEDIDO
                     }
                     
                    }];
                R.effectiveDateTime=record.FECHA_PEDIDO;
                R.status = record.STATUS;
                R.category = {
                    coding: [{
                        system: "http://terminology.hl7.org/CodeSystem/v2-0074",
                        code: "LAB"
                    }]
                };

                R.code = {
                    coding: [{
                        system: "http://loinc.org",
                        code: "18842-5"
                    }]
                };

               
                result.push(R);
            });

            let entries = result.map(diagnosticreport =>
                new BundleEntry({
                    fullUrl: baseUrl + 'DiagnosticReport/' + diagnosticreport.id,
                    resource: diagnosticreport
                }));
            let bundle = new Bundle({
                id: uuidv4(),
                meta: {
                    lastUpdated: new Date()
                },
                type: "searchset",
                total: entries.length,
                entry: entries
            });
            resolve(bundle);

        }
    )

});

function GetBaseUrl(context) {
    var baseUrl = "";
    const FHIRVersion = "/4_0_0/";
    var protocol = "http://";
    if (context.req.secure) { protocol = "https://"; }
    baseUrl = protocol + context.req.headers.host + FHIRVersion;
    return baseUrl;

};

function AddEntry(dict, tag, value) {

    var e = new Object;
    e.tag = tag;
    e.value = value;
    dict.push(e);
    return dict;
}

function CreateDictionary(rPaciente, rReporte) {
    /*
      'numero',           'paciente',
      'medico_nombre',    'origen',
      'id_consolidado',   'cobertura',
      'fecha_nacimiento', 'edad',
      'sexo',             'fecha_extraccion',
      'int_sector',       'int_habitacion',
      'int_cama',         'fecha_impresion'
    */
    dict = [];
    dict = AddEntry(dict, "medico_nombre", rReporte.MEDICO_SOLICITANTE);
    dict = AddEntry(dict, "medico_solicitante", rReporte.MEDICO_SOLICITANTE);

    dict = AddEntry(dict, "documento", rPaciente.PACIENTE_TIPO_NRO_DOC);

    dict = AddEntry(dict,
        tag = "numero",
        value = rReporte.ORDEN_IDENTIFICADOR
    );
    dict = AddEntry(dict,

        tag = "fecha_ingreso",
        value = dateformat(rReporte.ORDEN_FECHA, "dd/mm/yyyy HH:MM")
    );
    dict = AddEntry(dict,
        tag = "PRIORIDAD_PEDIDO",
        value = "R"
    );
    dict = AddEntry(dict,
        tag = "clase_pedido",
        value = "A"
    );
    dict = AddEntry(dict,
        tag = "comentario",
        value = "-");
    dict = AddEntry(dict,

        tag = "NRO_AFILIADO",
        value = "-");

    dict = AddEntry(dict,
        tag = "DIAG_PRESUN",
        value = "-");

    dict = AddEntry(dict,
        tag = "APELLIDO",
        value = rPaciente.PACIENTE_APELLIDO
    );
    dict = AddEntry(dict,
        tag = "NOMBRES",
        value = rPaciente.PACIENTE_NOMBRE
    );
    dict = AddEntry(dict,
        tag = "paciente",
        value = rPaciente.PACIENTE_APELLIDO + "," + rPaciente.PACIENTE_NOMBRE
    );
    dict = AddEntry(dict,
        tag = "fecha_nacimiento",
        value = dateformat(rPaciente.PACIENTE_FECHA_NAC, "dd/mm/yyyy")
    );
    var sx = 'Femenino';
    if (rPaciente.PACIENTE_SEXO == 'male') { sx = 'Masculino'; }
    dict = AddEntry(dict,
        tag = "sexo",
        value = sx
    );
    dict = AddEntry(dict,
        tag = "id_consolidado",
        value = rPaciente.PACIENTE_ID
    );
    dict = AddEntry(dict,
        tag = "nota",
        value = "-"
    );
    dict = AddEntry(dict,
        tag = "razon_social",
        value = rReporte.RAZON_SOCIAL
    );
    dict = AddEntry(dict,
        tag = "cobertura",
        value = rReporte.RAZON_SOCIAL
    );
    dict = AddEntry(dict,
        tag = "marca",
        value = "-"
    );
    dict = AddEntry(dict,
        tag = "documento_c",
        value = "-"
    );
    dict = AddEntry(dict,
        tag = "apellido_c",
        value = "-"
    );
    dict = AddEntry(dict,
        tag = "nombres_c",
        value = "-"
    );
    dict = AddEntry(dict,
        tag = "paciente_c",
        value = "-"
    );
    dict = AddEntry(dict,
        tag = "fecha_normalizada",
        value = dateformat(rReporte.ORDEN_FECHA, "dd/mm/yyyy")
    );

    dict = AddEntry(dict,
        tag = "edad",
        value = rReporte.EDAD
    );
    dict = AddEntry(dict,
        tag = "fecha_procesamiento_datos",
        value = dateformat(new Date(), "dd/mm/yyyy HH:MM")
    );
    dict = AddEntry(dict,
        tag = "medico_da",
        value = "-"
    );
    dict = AddEntry(dict,
        tag = "fecha_impresion",
        value = dateformat(new Date(), "dd/mm/yyyy HH:MM")
    );
    dict = AddEntry(dict,
        tag = "clave_unica",
        value = rReporte.REPORTE_ID
    );
    dict = AddEntry(dict,
        tag = "NUMERO_MATRICULA",
        value = "-"
    );
    dict = AddEntry(dict,
        tag = "int_historia",
        value = rReporte.INT_HISTORIA
    );
    dict = AddEntry(dict,
        tag = "int_sector",
        value = rReporte.INT_SECTOR
    );
    dict = AddEntry(dict,
        tag = "int_cama",
        value = rReporte.INT_CAMA
    );
    dict = AddEntry(dict,
        tag = "hora",
        value = dateformat(rReporte.ORDEN_FECHA, "hh:MM")
    );
    dict = AddEntry(dict,
        tag = "fecha_extraccion",
        value = dateformat(rReporte.COLLECTION, "dd/mm/yyyy HH:MM")
    );
    dict = AddEntry(dict,
        tag = "parcial",
        value = "parcial"
    );
    dict = AddEntry(dict,
        tag = "pagina",
        value = ""
    );
    dict = AddEntry(dict,
        tag = "hpagina",
        value = ""
    );
    dict = AddEntry(dict,
        tag = "DE",
        value = "de"
    );
    dict = AddEntry(dict,
        tag = "origen",
        value = rReporte.LOCALIZACION
    );
    return dict;
}


function CreateResultItemDictionary(result, refPrestacion, OrdenMuestra) {
    dict = [];
    if ((refPrestacion) && (result)) {
        result.forEach(element => {

            if ((element.RTYPE == 'RES') && (element.ORDEN_MUESTRA == OrdenMuestra)) {
                if (element.REFERENCIA_PRESTACION == refPrestacion) {
                    var resu = new Object;
                    resu.DESCRIPCION = element.OBSERVACION_DESCRIPCION;
                    resu.METODO = element.RESULTADO_METODO;
                    if (element.RESULTADO_NUM!=null)
                    {resu.NUM = element.RESULTADO_NUM.toFixed(element.DECIMALES);}
                    else
                    {resu.num = null }
                    resu.CODIGO = element.OBSERVACION_CODIGO;
                    resu.ALFA = element.RESULTADO_ALFA;
                    resu.FLAG = element.RESULTADO_FLAG;
                    resu.PANIC = element.RESULTADO_PANIC;
                    resu.TEXTO = element.RESULTADO_TEXTO;
                    resu.UNIDAD = element.RESULTADO_UNIDAD;
                    resu.COMENTARIO = element.RESULTADO_COMENTARIO;
                    resu.VR_DESDE = element.RESULTADO_VR_DESDE;
                    resu.VR_HASTA = element.RESULTADO_VR_HASTA;
                    resu.VR_TEXT = element.RESULTADO_VR_TEXT;
                    resu.TIPO = element.RESULTADO_TIPO;
                    resu.MOD_NUM = element.RESULTADO_MODIFICADOR_NUM;
                    resu.VR_TIPO = element.RESULTADO_TIPO_VALOR;
                    resu.DESC_MUESTRA = element.DESC_MUESTRA;
                    resu.TIPO_MUESTRA = element.TIPO_MUESTRA;
                    resu.LIBRE_MUESTRA = element.LIBRE_MUESTRA;
                    resu.SUBFAMILIA_MUESTRA = element.SUBFAMILIA_MUESTRA;
                    resu.ORDEN_MUESTRA = element.ORDEN_MUESTRA;
                    dict.push(resu);
                }
            }

        });
    }
    return dict;
}

function CreateReplacementDictionary(textIn) {
    var dicc = [];
    var p2 = -1;
    var p1 = -1;
    var st = "";
    p1 = textIn.indexOf("[");
    while (p1 != -1) {
        p2 = textIn.indexOf("]", p2 + 1)
        st = textIn.substring(p1 + 1, p2);
        dicc.push(st);
        p1 = textIn.indexOf("[", p2 + 1);
    }
    return dicc;

}

function encode_base64(filename) {
    const LongFileName = __dirname + '/' + filename;
    var data;
    var base64;
    try {
        data = fs.readFileSync(LongFileName);
        var buf = Buffer.from(data);
        base64 = buf.toString('base64');
    } catch {
        base64 = "";
    }
    return base64;

}

function ChangeImageReferences(htmlIn) {
    var aux = "";

    aux = htmlIn;
    p1 = aux.indexOf("images/");
    while (p1 != -1) {
        var ImageName = "";
        var ImageFile = "";
        var RealPath = "";
        p2 = aux.indexOf('"', p1 + 1)
        var refExternal = aux.substring(p1, p2);
        auxR = refExternal;
        FullName = auxR;
        RealPath = refExternal;
        ImageFile = encode_base64(RealPath)
        var Ext = 'image/png';
        if (RealPath.indexOf('gif') > -1) { Ext = 'image/gif'; }
        ImageName = 'data:' + Ext + ';base64,' + ImageFile;
        aux = aux.replace('"' + refExternal + '"', ImageName);

        p1 = aux.indexOf("images/");

    }
    return aux;
}

function ExtractBody(htmlIn, rPaciente, rReporte) {

    var aux = '';
    if (htmlIn) {
        aux = htmlIn.replace('<BODY>', '');
        aux = aux.replace('</BODY>', '');
        aux = aux.replace('<HTML>', '');
        aux = aux.replace('</HTML>', '');
        aux = aux.replace('<HEAD>', '');
        aux = aux.replace('<!-- written by TX_HTML32 6.00.120.500 -->', '');
        aux = aux.replace('<TITLE>Encabezado Talon</TITLE>', '');
        aux = aux.replace('<TITLE>', '');
        aux = aux.replace('</TITLE>', '');
        aux = aux.replace('</HEAD>', '');
        aux = aux.replace('<BODY BGCOLOR="#FFFFFF" TEXT="#000000" LINK="#0000FF">', "");
        aux = aux.replace("\n", "");
        ForDiccio = CreateReplacementDictionary(aux);
        OwnDiccio = CreateDictionary(rPaciente, rReporte);
        ForDiccio.forEach(MyTag => {
            var MyValue = "";
            sTag = MyTag.split("|");
            Tag = sTag[0];
            Len = sTag[1];
            OwnDiccio.forEach(MyEntry => {
                if (MyEntry.tag.toUpperCase() == Tag.toUpperCase()) {

                    MyValue = MyEntry.value;
                    //if (Len) { MyValue = MyValue.substring(1, Len); }
                }
            });

            if (Len) { aux = aux.replace("[" + Tag + "|" + Len + "]", MyValue); } else { aux = aux.replace("[" + Tag + "]", MyValue); }

        });
        aux = ChangeImageReferences(aux);
    } else {
        aux = "";
    }
    return aux;
}

function ResultClean(text) {
    aux = text;
    //Si es HTML se respeta pero se reemplaza HTML por nada
    if (aux.indexOf("<HTML>") != -1) {
        aux = aux.replace("<HTML><HEAD><TITLE></TITLE></HEAD>", "");
        aux = aux.replace("</HTML>", "");
    } else {
        aux = entities.encode(aux);

    }

    aux = aux.replace(/\n/g, "<br/>");
    return aux;
}

function DiccioReplace(Template, Property, Length, OwnDiccio) {
    var aux = Template;
    OwnDiccio.forEach(MyTag => {
        if (MyTag == Property) {
            var MyValue = "";
            switch (Property) {
                case "M":
                    MyValue = entities.encode(MyResult.METODO).replace("\n", "<br/>");
                    break;
                case "U":
                    MyValue = entities.encode(MyResult.UNIDAD);
                    break;
                case "N":
                    MyValue = entities.encode(MyResult.COMENTARIO).replace("\n", "<br/>");;
                    break;
                case "V":
                    switch (MyResult.VR_TIPO) {
                        case "R":
                            MyValue = MyResult.VR_DESDE + "-" + MyResult.VR_HASTA;
                            break;
                        case "D":
                            MyValue = "Desde " + MyResult.VR_DESDE;
                            break;
                        case "H":
                            MyValue = "Hasta " + MyResult.VR_HASTA;
                            break;
                        case "L":
                            MyValue = MyResult.VR_TEXT;
                            break;
                        default:
                            MyValue = "";
                            break
                    }
                    break;
                case "R":
                    if (MyResult.TIPO = 'M') { MyValue = ResultClean(MyResult.TEXTO); } else
                    if (MyResult.TIPO == 'N') {
                        MyValue = MyResult.NUM;
                        if (MyResult.MOD_NUM) {
                            if (MyResult.MOD_NUM != '') {
                                MyValue = entities.encode(MyResult.MOD_NUM) + MyValue;
                            }
                        }
                    } else { MyValue = MyResult.ALFA; }
                    if (MyValue="-") {MyValue=" ";}
                    if (MyResult.PANIC=='AA')
                    {
                        MyValue=MyValue+" ! ";
                    }
                    break;

                case "RN":
                    MyValue = MyResult.NUM;
                    if (MyResult.PANIC=='AA')
                    {
                        MyValue=MyValue+" ! ";
                    }

                    break;

                case "RT":
                    MyValue = entities.encode(MyResult.TEXTO);
                    
                    break;

                case "RA":
                    MyValue = entities.encode(MyResult.ALFA);
                    break;
                default:
                    MyValue = "";
                    break
            }

            var MyTag = "[" + Analyte + "|" + Property + "]";
            if (!MyValue) { MyValue = ""; }
            if (MyValue=="-"){ MyValue = ""; }
            aux = aux.replace(MyTag, MyValue);

        }
    });
    return aux;
}

function DiccioTestReplace(Analyte, Property, OwnDiccio, Template) {
    var aux = Template;
   
    OwnDiccio.forEach(MyResult => {
        var MyValue = "";
        
        if (MyResult.CODIGO == Analyte) {
            
            switch (Property) {
                case "RH":
                    MyValue = "";
                    break;

                case "TI":
                    MyValue = "";
                    break;
                case "MS":
                    MyValue = "";
                    if ((MyResult.SUBFAMILIA_MUESTRA)) { MyValue = MyResult.SUBFAMILIA_MUESTRA; }
                    break;

                case "MQ":
                    MyValue = "";
                    if ((MyResult.TIPO_MUESTRA)) { MyValue = MyResult.TIPO_MUESTRA; }
                    break;

                case "ML":
                    MyValue = "";
                    if ((MyResult.LIBRE_MUESTRA)) { MyValue = MyResult.DESC_MUESTRA; }
                    break;

                case "MT":
                    if (!(MyResult.DESC_MUESTRA)) { MyValue = MyResult.ORDEN_MUESTRA; } else { MyValue = MyResult.DESC_MUESTRA; }
                    break;

                case "DD":
                    var MyRes = "";
                    if ((MyResult.TIPO == 'M') || (MyResult.TIPO == 'T')) {
                        MyRes = ResultClean(MyResult.TEXTO);
                    } else
                    if (MyResult.TIPO == 'N') {
                        MyRes = MyResult.NUM;
                       
                    } else
                    if (MyResult.TIPO == "A") { MyRes = ResultClean(MyResult.ALFA); }
                    console.log("DD");
                    console.log("TIPO");
                    console.log(MyResult.TIPO);
                    console.log("RESULTADO");
                    console.log(MyRes);
                    MyValue="";
                    if (MyRes.toString()!="")
                    {
                        MyValue = entities.encode(MyResult.DESCRIPCION);
                      
                    }
                    break;
                case "M":
                    MyValue = entities.encode(MyResult.METODO).replace("\n", "<br/>");
                    break;
                case "U":
                    MyValue = entities.encode(MyResult.UNIDAD);
                    break;
                case "N":
                    MyValue = entities.encode(MyResult.COMENTARIO).replace("\n", "<br/>");
                    break;
                case "V":
                    switch (MyResult.VR_TIPO) {
                        case "R":
                            MyValue = MyResult.VR_DESDE + "-" + MyResult.VR_HASTA;
                            break;
                        case "D":
                            MyValue = "Desde " + MyResult.VR_DESDE;
                            break;
                        case "H":
                            MyValue = "Hasta " + MyResult.VR_HASTA;
                            break;
                        case "L":
                            MyValue = MyResult.VR_TEXT;
                            break;
                        default:
                            MyValue = "";
                            break
                    }
                    break;
                case "R":
                    MyValue = " ";
                    if ((MyResult.TIPO == 'M') || (MyResult.TIPO == 'T')) {
                        MyValue = ResultClean(MyResult.TEXTO);
                    } else
                    if (MyResult.TIPO == 'N') {
                        MyValue = MyResult.NUM;
                        if ((MyResult.MOD_NUM) && (MyResult.MOD_NUM != "")) { MyValue = MyResult.MOD_NUM + MyResult.NUM; }
                        if (typeof MyValue === 'undefined') {
                            MyValue = " "
                        };


                    } else
                    if (MyResult.TIPO == "A") { MyValue = ResultClean(MyResult.ALFA); }
                    if (MyResult.PANIC=="AA")
                    {
                        MyValue = '<FONT COLOR="#ff0000">'+MyValue + '</FONT>';
                    }
                   
                    break;



                case "RN":
                    MyValue = MyResult.NUM;
                    
                    if (MyValue==null)
                        MyValue="";

                    if ((MyResult.MOD_NUM) && (MyResult.MOD_NUM != "")) { MyValue = MyResult.MOD_NUM + MyResult.NUM };
                    if (MyResult.PANIC=="AA")
                    {
                        MyValue = '<FONT COLOR="#ff0000">'+MyValue + '</FONT>';
                    }
                    break;

                case "RT":
                    MyValue = ResultClean(MyResult.TEXTO);
                    break;

                case "RA":
                    MyValue = ResultClean(MyResult.ALFA);
                    break;
                case "F":
                    MyValue="";
                    if (MyResult.FLAG=="H")
                        {MyValue="&#8593";}
                    if (MyResult.FLAG=="L")
                        {MyValue="&#8595";}
                    break;
                default:
                    MyValue = "";
                    break
            }
            if (typeof MyValue === 'undefined') {

                MyValue = "";
            }
            if (MyValue=="-"){MyValue="";}
            var MyTag = "[" + Analyte + "|" + Property + "]";
            console.log(MyTag+"/"+MyValue);
            
            aux = aux.replace(MyTag, MyValue);

        }
    });
    //No results: aux=template
    // if (aux == Template)
    //     aux = "";
    return aux;
}

function ExtractBodyItem(htmlIn, result, refPrestacion, OrdenMuestra) {

    var aux = '';
    if (htmlIn) {
        aux = htmlIn.replace('<BODY>', '');
        aux = aux.replace('</BODY>', '');
        aux = aux.replace('<HTML>', '');
        aux = aux.replace('</HTML>', '');
        aux = aux.replace('<BODY BGCOLOR="#FFFFFF" TEXT="#000000" LINK="#0000FF">', '');
        aux = aux.replace('<HEAD>', '');
        aux = aux.replace('<!-- written by TX_HTML32 6.00.120.500 -->', '');
        aux = aux.replace('<TITLE></TITLE>', '');
        aux = aux.replace('</HEAD>', '');
        //Este diccionario contiene todos los tags a reemplazar en el HTML
        ForDiccio = CreateReplacementDictionary(aux);
        //Este diccionario contiene todos los resultados para la prestacion

        OwnDiccio = CreateResultItemDictionary(result, refPrestacion, OrdenMuestra);
        if (OwnDiccio.length>0)

        {
            ForDiccio.forEach(MyTag => {

            var sp = MyTag.split("|");
            var Analyte = sp[0];
            var Property = sp[1];
            //console.log("Analito:"+Analyte+"|"+Property);
            aux = DiccioTestReplace(Analyte, Property, OwnDiccio, aux);
            if (MyTag.indexOf("|DD")!=-1)
            {
                //console.log("ES un DD!");
                aux=ReplaceUnusedDD(aux,"[" +MyTag+ "]");
            
            }
            else
            {
              //  console.log("Reemplazo","[" + MyTag + "]");
                aux = aux.replace("[" + MyTag + "]", "");
            }

        });
    }
    else
    {
        aux="PENDIENTE";
    }
    } else {
        aux = "";
    }
    return aux;

}
function ReplaceHTML(st)
{

    arrWhatToReplace=
    [
    
       { s:"<B>",r:""},
       { s:"</B>",r:""},
       { s:"<TR>",r:""},
       { s:"</TR>",r:"\r\n"},
       { s:"<TABLE COLS=1>",r:""},
       { s:"</TABLE>",r:""},
       { s:"<TD WIDTH=696>",r:""},
       { s:"<TD WIDTH=400>",r:""},
       { s:"<TD WIDTH=448>",r:""},
       { s:"<TD WIDTH=372>",r:""},
       { s:"<TD WIDTH=65>",r:""},
       { s:"<TD WIDTH=350>",r:""},
       { s:"<TD WIDTH=142>",r:""},
       { s:"<TD WIDTH=192>",r:""},
       { s:"<TABLE COLS=4>",r:""},
       { s:"</TD>",r:" / "},
       { s:"<TR ALIGN=LEFT VALIGN=TOP>",r:""},
       { s:"<DIV>",r:""},
       { s:"</DIV>",r:""},
       { s:"Antibiograma para ",r:"\n\rAntibiograma para "}  ,
       { s:"<TABLE COLS=3>", r:"\r\n"},
       { s:"<TABLE COLS=2>", r:"\r\n"},
       { s:"<TD WIDTH=200>",  r:""},
       { s:"<TD WIDTH=228>",  r:""},
       { s:"/  /  /", r:"\r\n"},
       { s:"/   /  /", r:""},
       { s:"\t", r:""}
       
    ];
    aux=st;
    arrWhatToReplace.forEach(a =>
        
        {
            aux=aux.split(a.s).join(a.r);
    
        })
    aux = aux.replace('<BODY>', '');
    aux = aux.replace('</BODY>', '');
    aux = aux.replace('<HTML>', '');
    aux = aux.replace('</HTML>', '');
    aux = aux.replace('<BODY BGCOLOR="#FFFFFF" TEXT="#000000" LINK="#0000FF">', '');
    aux = aux.replace('<HEAD>', '');
    aux = aux.replace('<!-- written by TX_HTML32 6.00.120.500 -->', '');
    aux = aux.replace('<TITLE></TITLE>', '');
    aux = aux.replace('</HEAD>', '');
    return aux;

}
function ReplaceUnusedDD(textIn,tag)
{
    var aux=textIn;
    p1=aux.indexOf(tag);
    if (p1 != -1) {
       // console.log('tag encontrado:',tag);
         sComplete = aux.split(tag);
        //Part 1: Todo lo que esta a la izquierda del DD
        var cabeza=sComplete[0];
        var cola=sComplete[1];
        var p2=cabeza.lastIndexOf("<TR");
        var p3=cola.indexOf("</TR>");
    
        if (p2!=-1)
        {
            cabeza=cabeza.substring(0,p2-1);
        }
        //Part 2: Todo lo que esta a la derecha del DD
        if (p3!=-1)
        {
           cola=cola.substring(p3+5,cola.length);
        }
        
        aux=cabeza+cola;
        
    }
    return aux;
}

function CompletarReporte(rReporte, rPaciente, result) {
    var aux = "";

    var HTMLEncabezado = '';
    var HTMLPie = '';
    var HTMLCuerpo = '';

    result.forEach(element => {

        if (element.RTYPE == 'FMT') {
            if (element.DESCRIPCION == 'ENCABEZADO INFORME') {
                HTMLEncabezado = ExtractBody(element.SECTOR_TEXTO, rPaciente, rReporte);


            } else {
                HTMLPie = ExtractBody(element.SECTOR_TEXTO, rPaciente, rReporte);

            }
        } else {
            if (element.RTYPE == 'ITE') {
                if (element.CANTIDAD == 1)

                 { 
                    PrestacionBody= ExtractBodyItem(element.FORMATO, result, element.RENGLON_REFERENCIA, 1);
                    if (PrestacionBody=="PENDIENTE")
                    {
                        PrestacionBody=
                        "<TABLE COLS=2><TR><TD WIDTH=312><B>"+element.RENGLON_DESCRIPCION+"</B></TD><TD>Pendiente</TD></TABLE>";
                    }
                    HTMLCuerpo = HTMLCuerpo + PrestacionBody;
                 } else {
                    var i = 1;
                    while (i <= element.CANTIDAD) {
                        PrestacionBody=ExtractBodyItem(element.FORMATO, result, element.RENGLON_REFERENCIA, i);
                        if (PrestacionBody=="PENDIENTE")
                        {
                            PrestacionBody=
                            "<TABLE COLS=2><TR><TD WIDTH=312><B>"+element.RENGLON_DESCRIPCION+"</B></TD><TD>Pendiente</TD></TABLE>";
                        }   HTMLCuerpo = HTMLCuerpo + PrestacionBody;
                        i++;
                    }

                }

            }
        }

    });
    HTMLEncabezado = HTMLEncabezado.replace(/\n/g, ' ');

    HTMLCuerpo = HTMLCuerpo.replace(/\n/g, ' ');
    HTMLPie = HTMLPie.replace(/\n/g, ' ');
    aux = "<html>";
    aux = aux + "<body>";
    aux = aux + HTMLEncabezado + HTMLCuerpo + HTMLPie;
    aux = aux + "</body>";
    aux = aux + "</html>";
    aux = aux.replace('<HEAD><!-- written by TX_HTML32 6.00.120.500 --><TITLE>Encabezado Talon</TITLE></HEAD><BODY BGCOLOR=\"#FFFFFF\" TEXT=\"#000000\" LINK=\"#0000FF\">', "");
    return aux;

}

module.exports.searchById = (args, context, logger) => new Promise((resolve, reject) => {
    //	logger.info('DiagnosticReport >>> searchById');

    let { base_version, id } = args;
    let baseUrl = GetBaseUrl(context);

    // TODO: Query database q
    sequelize.query(
        query = sp("ReporteObtenerPorClave"), {
            replacements: { idp: id },
            type: sequelize.QueryTypes.SELECT
        }).then(
        result => {
            let R = new getDiagnosticReport();
            let O=new getRequestGroup();
            let E=new getEncounter();
            let S=new getSpecimen();
            //TRAE UN SOLO REGISTRO	
            let rPaciente = result[0];
            let rReporte = result[1];
            S.id="Muestra";
            S.collection=
            {
                collectedDateTime:rReporte.COLLECTION
            };
            E.id="Encuentro";
            E.status="unknown";
            E.location=
            [
             {
                 location:  
                    {
                        identifier:
                        
                            {
                                system:  'http://www.labdl.com.ar/ubicaciones_ha_id',
                                value: rReporte.LOCATION
                        }
                        
                    }
            }
            ];
            O.id="Orden";
            O.encounter=
            {
                reference:"#Encuentro"
            };
            O.identifier= [
                {
                system: urlbase + '/orden_ha_id',
                value: rReporte.ORDEN_IDENTIFICADOR_HA
            },
            {
                system: urlbase + '/orden_lab_id',
                value: rReporte.ORDEN_IDENTIFICADOR
            },
            ];
            var actions=[];
            console.log("My Order");
            console.log(JSON.stringify(O));
            R.id = id;
            console.log(rReporte.REPORTE_CONFIDENCIAL.toString());
            
            if (rReporte.REPORTE_CONFIDENCIAL.toString()=="true")
            {
                R.meta= {
                    "security": [
                        {
                            "system": "http://terminology.hl7.org/CodeSystem/v3-Confidentiality",
                            "code": "R",
                            "display": "Restricted"
                        }
                    ]
                };
            }
       
            R.issued = rReporte.REPORTE_FECHA;
            R.identifier = [{
                system: urlbase + '/diag_rep_id',
                value: rReporte.REPORTE_IDENTIFICADOR
            }];
            R.basedOn={
                reference:"#Orden"
            }
            R.status = rReporte.REPORTE_ESTADO;
            R.category = {
                coding: [{
                    system: "http://terminology.hl7.org/CodeSystem/v2-0074",
                    code: "LAB"
                }]
            };

            R.code = {
                coding: [{
                    system: "http://loinc.org",
                    code: "18842-5"
                }]
            };
            if (rReporte.REPORTE_ESTADO == 'final') {
                var ReporteCompleto =
                CompletarReporte(rReporte, rPaciente, result);
                let buff = new Buffer.from(ReporteCompleto);
                let base64data = buff.toString('base64');
           
                R.presentedForm =
               [ {
                    contentType: "application/pdf",
                    data: rReporte.REPORTE_PDF
                },
                {
                    contentType: "text/html",
                    data: base64data
                }];
            
            } else {
                var ReporteCompleto =
                    CompletarReporte(rReporte, rPaciente, result);
                let buff = new Buffer.from(ReporteCompleto);
                let base64data = buff.toString('base64');
                R.presentedForm = {
                    contentType: "text/html",
                    data: base64data
                };


            }
            R.subject = { 
                identifier:{system: urlbase + "/lab_id",
                            value:rPaciente.PACIENTE_ID
                        }
            }
            R.specimen=
            [{
              reference:"#Muestra"      
            }];
            R.contained = [];

            O.status="active";
            O.intent="order";
            O.subject=R.subject;
            
            O.action = [];
            var AllObservationsRef = [];
            
            result.forEach(element => {
                switch (element.RTYPE ) 
                {
                case "RES":
                    {
                    var obsIns = new getObservation();

                    obsIns.id = element.ID_RESULTADO;
                    obsIns.extension=
                    [{
                        "url": urlbase + "/StructureDefinition/relacion_prestacion",
                        "valueString": element.REFERENCIA_PRESTACION
                    }];
                    //ESTADO
                    obsIns.status = "final";
                    //CODIGO
                    obsIns.code = {
                        coding: [{
                            system: urlbase + "/CodeSystem/observation_code",
                            code: element.OBSERVACION_CODIGO,
                            display: element.OBSERVACION_DESCRIPCION
                        }]
                    };
                    //PACIENTE
                    obsIns.subject = R.subject;
                    //METODO
                    if (element.RESULTADO_METODO!="")
                    {
                        if (element.RESULTAD_METODO!="-")
                        {
                            obsIns.method = { text: element.RESULTADO_METODO };
                        }
                    }
                    switch (element.RESULTADO_TIPO) {

                        case "N":
                            //VALOR NUMERICO
                            
                            obsIns.valueQuantity = {
                                value: element.RESULTADO_NUM.toFixed(element.DECIMALES),
                                unit: element.RESULTADO_UNIDAD,
                                system: "http://unitsofmeasure.org/",
                                code: element.RESULTADO_UNIDAD

                            };
                            //MODIFICADOR NUMERICO
                            if (element.RESULTADO_MODIFICADOR_NUM != 'null')

                            {
                                if (element.RESULTADO_MODIFICADOR_NUM != '   ') {
                                    obsIns.valueQuantity.comparator = element.RESULTADO_MODIFICADOR_NUM;
                                }
                            }
                            
                            //INTERPRETACION
                            obsIns.interpretation 
                            = [
                                {
                                coding: [{
                                    system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
                                    code: element.RESULTADO_FLAG
                                }]
                                }
                            ];
                            if (element.RESULTADO_PANIC != '')
                            {
                           
                                obsIns.interpretation 
                                = [
                                    {
                                    coding: [{
                                        system: "https://www.hl7.org/fhir/v3/ObservationInterpretation",
                                        code: element.RESULTADO_FLAG
                                    }]
                                    },
                                    {
                                        coding: [{
                                            system: "https://www.hl7.org/fhir/v3/ObservationInterpretation",
                                            code: element.RESULTADO_PANIC
                                    }]
                                    }
                                ];
                               
                                
                            }
                            //RANGO REFERENCIA
                            switch (element.RESULTADO_TIPO_VALOR) {

                                case "R":
                                    obsIns.referenceRange = [{
                                        low: {
                                            value: element.RESULTADO_VR_DESDE,
                                            unit: element.RESULTADO_UNIDAD,
                                            system: "http://unitsofmeasure.org/"
                                        },
                                        high: {
                                            value: element.RESULTADO_VR_HASTA,
                                            unit: element.RESULTADO_UNIDAD,
                                            system: "http://unitsofmeasure.org/"
                                        }
                                    }];
                                    //VALIDEZ RANGO REFERENCIA
                                    obsIns.modifierExtension = [{
                                        url: urlbase + "/StructureDefinition/validezrangoreferencia",
                                        valuePeriod: { start: element.RESULTADO_VR_FECHA }
                                    }];
                                    
                                    break;
                                case "D":
                                    obsIns.referenceRange = [{
                                        low: {
                                            value: element.RESULTADO_VR_DESDE,
                                            unit: element.RESULTADO_UNIDAD,
                                            system: "http://unitsofmeasure.org/"
                                        },
                                    }];
                                    //VALIDEZ RANGO REFERENCIA
                                    obsIns.modifierExtension = [{
                                        url: urlbase+"/StructureDefinition/validezrangoreferencia",
                                        valuePeriod: { start: element.RESULTADO_VR_FECHA }
                                    }];
                                    
                                    break;

                                case "L":
                                    obsIns.referenceRange = [{
                                        text: element.RESULTADO_VR_TEXT
                                    }];
                                    //VALIDEZ RANGO REFERENCIA
                                    obsIns.modifierExtension = [{
                                        url: urlbase +"/StructureDefinition/validezrangoreferencia",
                                        valuePeriod: { start: element.RESULTADO_VR_FECHA }
                                    }];

                                    break;

                                case "H":
                                    obsIns.referenceRange = [{
                                        high: {
                                            value: element.RESULTADO_VR_HASTA,
                                            unit: element.RESULTADO_UNIDAD,
                                            system: "http://unitsofmeasure.org/"
                                        }
                                    }];
                                    //VALIDEZ RANGO REFERENCIA
                                    obsIns.modifierExtension = [{
                                        url: urlbase +"/StructureDefinition/validezrangoreferencia",
                                        valuePeriod: { start: element.RESULTADO_VR_FECHA }
                                    }];
                                    
                                    break;

                                default:
                                    break;
                            };


                            break;
                        case "T":
                            var rtext=element.RESULTADO_TEXTO;
                            if (rtext.indexOf('<HTML>')>-1)
                            {
                                rtext=ReplaceHTML(rtext);
                            }

                            obsIns.valueString = rtext;
                            
                            break;
                        case "M":
                            var rtext=element.RESULTADO_TEXTO;
                            if (rtext.indexOf('<HTML>')>-1)
                            {
                                rtext=ReplaceHTML(rtext);
                            }

                            obsIns.valueString = rtext;
                            break;
                        case "A":
                            var rtext=element.RESULTADO_ALFA;
                            
                            obsIns.valueCodeableConcept = {text:rtext};
                            break;
                        default:
                    }
                    //COMENTARIO           
                    if (element.RESULTADO_COMENTARIO != '-') 
                    {   
                        var rtext =element.RESULTADO_COMENTARIO;
                        obsIns.note=[{text:rtext}];
                    }


                    R.contained.push(obsIns);
                    var obsRef = { reference: '#' + element.ID_RESULTADO };
                    AllObservationsRef.push(obsRef);
                    break;
                    };
                    case "ITE":
                        {
                            var act =  {
                                        prefix:element.RENGLON_REFERENCIA,
                                        code:
                                            [{
                                                coding:
                                                [
                                                    {code:element.RENGLON_CODIGO,
                                                    system: urlbase +'/CodeSystem/procedure_definition',
                                                    display:element.RENGLON_DESCRIPCION
                                                }
                                            ]
                                            }],
                                        type: {
                                                coding: {
                                                code: [
                                                    'update'
                                                ],
                                                system: 'http://terminology.hl7.org/CodeSystem/action-type'
                                            }
                                            }
                                    ,
                                    extension: 
                                    [
                                        { 
                                            url: urlbase +"/StructureDefinition/seccion_reporte",
                                            extension:
                                            [
                                                {
                                                url:"#seccion",
                                                valueString:element.SECCION_COD
                                                },
                                                {
                                                url:"#orden_seccion",
                                                valueInteger:element.ORDEN_SECCION
                                                },
                                                {
                                                url:"#orden_prestacion",
                                                valueInteger:element.ORDEN_PRESTACION
                                                },
                                                
                                            ]
                                        }, 
                                        
                                        {
                                           url: urlbase+"/StructureDefinition/tipo_muestra",
                                           extension:[
                                            {
                                                url: "#SpecimenType",
                                                valueCoding: {
                                                system: urlbase +"/CodeSystem/specimen_type",
                                                code: element.SPECIMEN_TYPE,
                                                display: element.SPECIMEN_TYPE
                                             },
                                            } ,
                                            {  
                                                url: "#BodySite",
                                                valueCoding: {
                                                system:  urlbase +"/CodeSystem/body_site",
                                                code: element.BODY_SITE,
                                                display: element.BODY_SITE
                                                },
                                            },
                                            {
                                                url: "#Description",
                                                valueString: element.SAMPLE_DESCRIPTION
                                            }
                                           ]
                                        }
                                    ]
                                };
                            
                            actions.push(act);
                            
                            break;
                        }
                    default: break;


                }
            });
            //console.log(JSON.stringify(O));
            O.action=actions;
            R.contained.push(O);
            R.contained.push(S);
            R.contained.push(E);
            R.result = AllObservationsRef;
            // resolve(DiagnosticReport_resource);
            resolve(R);

        }
    )


})