const { initialize, loggers, constants } = require('@asymmetrik/node-fhir-server-core');
const { VERSIONS } = constants;
let config = {
    profiles: {
		 documentreference:
        {
            service: './documentreference.service.js',
            versions: [
                VERSIONS['4_0_0']
            ]
        },
        organization:
        {
            service: './organization.service.js',
            versions: [
                VERSIONS['4_0_0']
            ]
        },
        patient: {
            service: './patient.service.js',
            versions: [
                VERSIONS['4_0_0']
            ]
        },
        diagnosticreport: {
            service: './diagnosticreport.service.js',
            versions: [
                VERSIONS['4_0_0']
            ]
        }

        ,
        practitioner: {
            service: './practitioner.service.js',
            versions: [
                VERSIONS['4_0_0']
            ]
        },
        location: {
            service: './location.service.js',
            versions: [
                VERSIONS['4_0_0']
            ]
        },
        requestGroup: {
            service: './requestgroup.service.js',
            versions: [
                VERSIONS['4_0_0']
            ],
            operation: [{
                name: 'activate',
                route: '/$activate',
                method: 'POST'
            }]
        },
        codesystem: {
            service: './codesystem.service.js',
            versions: [
                VERSIONS['4_0_0']
            ],
            operation: [{
                name: 'lookup',
                route: '/$lookup',
                method: 'GET',
                reference: 'https://www.hl7.org/fhir/codesystem-operation-lookup.html'
            }]
        }

    },
    auth: {
        strategy: {
            name: 'basic',
            service: './authentication.service.js'
        }
    }
};

let server = initialize(config);
let logger = loggers.get('default');

server.listen(process.env.PORT, () => {
    logger.info('Starting the FHIR Server at localhost: ', process.env.PORT);
	
});