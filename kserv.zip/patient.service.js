/*eslint no-unused-vars: "warn"*/
Sequelize = require('sequelize');
const uuidv4 = require('uuid/v4');
const sequelize = require('./dbconfig.js').db;
const urlbase = require('./config.js').urlbase;
const sp = require('./spconfig.js').sp;
const { RESOURCES } = require('@asymmetrik/node-fhir-server-core').constants;
const FHIRServer = require('@asymmetrik/node-fhir-server-core');
const getPatient = require('@asymmetrik/node-fhir-server-core/src/server/resources/4_0_0/schemas/patient');
const getBundle = require('@asymmetrik/node-fhir-server-core/src/server/resources/4_0_0/schemas/bundle');
const getBundleEntry = require('@asymmetrik/node-fhir-server-core/src/server/resources/4_0_0/schemas/bundleentry');
let getMeta = (base_version) => {
    return require(FHIRServer.resolveFromVersion(base_version, RESOURCES.META));
};

module.exports.search = (args, context, logger) => new Promise((resolve, reject) => {
    //	logger.info('Patient >>> search');

    // Common search params
    let { base_version, _content, _format, _id, _lastUpdated, _profile, _query, _security, _tag } = args;

    // Search Result params
    let { _INCLUDE, _REVINCLUDE, _SORT, _COUNT, _SUMMARY, _ELEMENTS, _CONTAINED, _CONTAINEDTYPED } = args;

    let name = args['name'];
    let iden = args['identifier'];
    // Resource Specific params
    if (iden) {
        query = sp("PacienteBuscarPorIdentificador");
        params = {
            replacements: { idc: iden },
            type: sequelize.QueryTypes.SELECT
        }
    }
    //search by name
    else {
        query = sp("PacienteBuscarPorApellido");
        params = {
            replacements: { nam: name + '%' },
            type: sequelize.QueryTypes.SELECT
        }
    }

    // TODO: Query database
    sequelize.query(query, params).then(
        data => {

            // Cast result to Patient Class
            //TRAE UN SOLO REGISTRO	
            var result = [];
            let BundleEntry = getBundleEntry;
            let Bundle = getBundle;
            data.forEach(record => {
                let R = new getPatient();
                R.id = record.PACIENTE_ID;
                R.name = {
                    family: record.APELLIDO,
                    given: [ record.NOMBRES ],
                    text: [record.APELLIDO+','+record.NOMBRES]
                };
                var date=new Date(record.FECHA_NACIMIENTO);
                date.setUTCHours(0,0,0,0);
                R.birthDate = date.toISOString().split('T')[0]
                if (record.SEXO == 'F') { R.gender = 'female' };
                if (record.SEXO == 'M') { R.gender = 'male' };
                R.identifier = [{
                        system: 'http://www.renaper.gob.ar/'+record.CODIGO_DOCUMENTO,
                        value: record.NRO_DOCUMENTO
                    },
                    {
                        system: urlbase+'/lis_paciente_id',
                        value: record.PACIENTE_ID
                    }
                ];
                if (record.NOTA=="Identificacion Temporaria")
                {
                    R.identifier[1].use="temp";
                }
                
                R.address= [ {
                    "line": [ record.DIRECCION ],
                    "city": record.LOCALIDAD,
                    "postalCode": record.COD_POS,
                    
                  } ];
                
                  R.telecom=[
                    {
                        system:"phone",
                        value:record.TELEFONO
                    },
                    {
                        system:"email",
                        value:record.EMAIL
                    },
                    
                  ];
                  
                result.push(R);
            });

            let entries = result.map(patient =>
                new BundleEntry({
                    fullUrl: urlbase+'/fhir/4_0_0/Patient/' + patient.id,
                    resource: patient
                }));
            let bundle = new Bundle({
                id: uuidv4(),
                meta: {
                    lastUpdated: new Date()
                },
                type: "searchset",
                total: entries.length,
                entry: entries
            });
            resolve(bundle);

        }
    )

});

module.exports.searchById = (args, context, logger) => new Promise((resolve, reject) => {
    //	logger.info('Patient >>> searchById');

    let { base_version, id } = args;

    // TODO: Query database q
    sequelize.query(sp("PacienteBuscarPorId"), {
        replacements: { idp: id },
        type: sequelize.QueryTypes.SELECT
    }).then(
        result => {
            // Cast result to Patient Class
            let R = new getPatient();
            //TRAE UN SOLO REGISTRO	
            let record = result[0];

            R.id = record.PACIENTE_ID;
            R.name = {
                family: record.APELLIDO,
                given: [ record.NOMBRES ],
                text: [record.APELLIDO]
            };
            var date=new Date(record.FECHA_NACIMIENTO);
            date.setUTCHours(0,0,0,0);
            R.birthDate = date.toISOString().split('T')[0]
            if (record.SEXO = 'F') { R.gender = 'female' };
            if (record.SEXO = 'M') { R.gender = 'male' };
            R.identifier = [{
                system: 'http://www.renaper.gob.ar/'+record.CODIGO_DOCUMENTO,
                value: record.NRO_DOCUMENTO
            },
            {
                system: urlbase+'/lis_paciente_id',
                value: record.PACIENTE_ID
            }
            ];
            if (record.NOTA=="Identificacion Temporaria")
            {
                R.identifier[1].use="temp";
            }
            // Return resource class
            // resolve(Patient_resource);
            resolve(R);

        }
    )

});

module.exports.create = (args, context, logger) => new Promise((resolve, reject) => {
    //  logger.info('RequestGroup >>> create');
    let { base_version, id, resource } = args;
    resource = context.req.body;
    
    
    var pat = resource;
    var orderHeader = [];
    //Paciente  ('Patient')
    

    orderHeader.push({ item: { clave: "patient-identifier_ext", valor: pat.identifier[0].system + "|" + pat.identifier[0].value } });
    if (pat.identifier[1])
    {
        orderHeader.push({ item: { clave: "patient-identifier_int", valor: pat.identifier[1].system + "|" + pat.identifier[1].value } });
    }
    if (pat.identifier[2])
    {
    orderHeader.push({ item: { clave: "patient-identifier_nat", valor: pat.identifier[2].system + "|" + pat.identifier[2].value } });
    }
    orderHeader.push({ item: { clave: "patient-family", valor: pat.name[0].family } });
    orderHeader.push({ item: { clave: "patient-given", valor: pat.name[0].given[0] } });
    orderHeader.push({ item: { clave: "patient-gender", valor: pat.gender } });
    orderHeader.push({ item: { clave: "patient-birth_date", valor: pat.birthDate } });
    orderHeader.push({ item: { clave: "patient-address", valor: pat.address[0].text } });
    //Números de telefono y direcciones de email
    ph = 0;
    em = 0;
    pat.telecom.forEach(tel => {
        if (tel.system == "phone") {
            ph = ph + 1;
            orderHeader.push({ item: { clave: "patient-phone-" + ph.toString(), valor: tel.value } });
        } else {
            em = em + 1;
            orderHeader.push({ item: { clave: "patient-email-" + em.toString(), valor: tel.value } });
        }

    });


    console.log("Phase #6");
    if (pat.extension)
    {
    pat.extension.forEach(ext => {
        switch (ext.url) {
            case "http://kern-it.com.ar/fhir/StructureDefinition/nota":
                orderHeader.push({ item: { clave: "patient.note", valor: ext.valueString } });
                break;
            case "http://kern-it.com.ar/fhir/StructureDefinition/autorizaciones":
                ext.extension.forEach(subExt => {
                    switch (subExt.url) {
                        case "#graba_web":
                            orderHeader.push({ item: { clave: "patient-graba_web", valor: subExt.valueBoolean } });
                            break;
                        case "#envio_mail":
                            orderHeader.push({ item: { clave: "patient-envio_mail", valor: subExt.valueBoolean } });

                            break;
                        case "#uso_academico":
                            orderHeader.push({ item: { clave: "patient-uso_academico", valor: subExt.valueBoolean } });

                            break;
                        default:
                            break;
                    }
                });
        }
    });
    }
    
    var xml2js = require('xml2js');
    var builder = new xml2js.Builder();
    var xmlHea = builder.buildObject(orderHeader);
    
    //Details
    query = sp("PacienteAgregar");
    param = {
        replacements: { hea: xmlHea },
        type: sequelize.QueryTypes.SELECT
    }
    sequelize.query(query, param).then(
        data => {
            console.log(JSON.stringify(data));
            resolve({ id: data[0].ID });
        });

});

module.exports.update = (args, context, logger) => new Promise((resolve, reject) => {
    //  logger.info('RequestGroup >>> create');
    let { base_version, id, resource } = args;
    resource = context.req.body;
    
    
    var pat = resource;
    var orderHeader = [];
    //Paciente  ('Patient')
    

    orderHeader.push({ item: { clave: "patient-identifier_ext", valor: pat.identifier[0].system + "|" + pat.identifier[0].value } });
    if (pat.identifier[1])
    {
        orderHeader.push({ item: { clave: "patient-identifier_int", valor: pat.identifier[1].system + "|" + pat.identifier[1].value } });
    }
    if (pat.identifier[2])
    {
    orderHeader.push({ item: { clave: "patient-identifier_nat", valor: pat.identifier[2].system + "|" + pat.identifier[2].value } });
    }
    orderHeader.push({ item: { clave: "patient-family", valor: pat.name[0].family } });
    orderHeader.push({ item: { clave: "patient-given", valor: pat.name[0].given[0] } });
    orderHeader.push({ item: { clave: "patient-gender", valor: pat.gender } });
    orderHeader.push({ item: { clave: "patient-birth_date", valor: pat.birthDate } });
    orderHeader.push({ item: { clave: "patient-address", valor: pat.address[0].text } });
    //Números de telefono y direcciones de email
    ph = 0;
    em = 0;
    pat.telecom.forEach(tel => {
        if (tel.system == "phone") {
            ph = ph + 1;
            orderHeader.push({ item: { clave: "patient-phone-" + ph.toString(), valor: tel.value } });
        } else {
            em = em + 1;
            orderHeader.push({ item: { clave: "patient-email-" + em.toString(), valor: tel.value } });
        }

    });


    console.log("Phase #6");
    if (pat.extension)
    {
    pat.extension.forEach(ext => {
        switch (ext.url) {
            case "http://kern-it.com.ar/fhir/StructureDefinition/nota":
                orderHeader.push({ item: { clave: "patient.note", valor: ext.valueString } });
                break;
            case "http://kern-it.com.ar/fhir/StructureDefinition/autorizaciones":
                ext.extension.forEach(subExt => {
                    switch (subExt.url) {
                        case "#graba_web":
                            orderHeader.push({ item: { clave: "patient-graba_web", valor: subExt.valueBoolean } });
                            break;
                        case "#envio_mail":
                            orderHeader.push({ item: { clave: "patient-envio_mail", valor: subExt.valueBoolean } });

                            break;
                        case "#uso_academico":
                            orderHeader.push({ item: { clave: "patient-uso_academico", valor: subExt.valueBoolean } });

                            break;
                        default:
                            break;
                    }
                });
        }
    });
    }
    
    var xml2js = require('xml2js');
    var builder = new xml2js.Builder();
    var xmlHea = builder.buildObject(orderHeader);
    
    //Details
    query = sp("PacienteAgregar");
    param = {
        replacements: { hea: xmlHea },
        type: sequelize.QueryTypes.SELECT
    }
    sequelize.query(query, param).then(
        data => {
            console.log(JSON.stringify(data));
            resolve({ id: data[0].ID });
        });

});
