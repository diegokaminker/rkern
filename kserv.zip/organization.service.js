/*eslint no-unused-vars: "warn"*/
Sequelize = require('sequelize');
const uuidv4 = require('uuid/v4');
const sequelize = require('./dbconfig.js').db;
const { RESOURCES } = require('@asymmetrik/node-fhir-server-core').constants;
const FHIRServer = require('@asymmetrik/node-fhir-server-core');
const getOrganization = require('@asymmetrik/node-fhir-server-core/src/server/resources/4_0_0/schemas/organization');
const getBundle = require('@asymmetrik/node-fhir-server-core/src/server/resources/4_0_0/schemas/bundle');
const getBundleEntry = require('@asymmetrik/node-fhir-server-core/src/server/resources/4_0_0/schemas/bundleentry');
const urlbase  = require('./config.js').urlbase;

let getMeta = (base_version) => {
    return require(FHIRServer.resolveFromVersion(base_version, RESOURCES.META));
};

module.exports.search = (args, context, logger) => new Promise((resolve, reject) => {
    //	logger.info('Location >>> search');

    // Common search params
    let { base_version, _content, _format, _id, _lastUpdated, _profile, _query, _security, _tag } = args;

    // Search Result params
    let { _INCLUDE, _REVINCLUDE, _SORT, _COUNT, _SUMMARY, _ELEMENTS, _CONTAINED, _CONTAINEDTYPED } = args;

    
    let iden = args['identifier'];
    var sp = require('./spconfig.js').sp;

    // Resource Specific params
        query = sp('ClienteBuscarPorCUIT'),
            params = {
                replacements: { cuit: iden },
                type: sequelize.QueryTypes.SELECT
            }
    
    // TODO: Query database
    sequelize.query(query, params).then(
        data => {

            // Cast result to Location Class
            //TRAE UN SOLO REGISTRO	
            var result = [];
            let BundleEntry = getBundleEntry;
            let Bundle = getBundle;
            data.forEach(record => {
                let R = new getOrganization();
                R.id = record.CO_CLIENTE_ID;
                R.name = record.RAZON_SOCIAL;
                R.identifier = [{
                        system: urlbase + '/clientes',
                        value: record.CODIGO
                    },
                    {
                        system: 'http://afip.gob.ar/cuit',
                        value: record.CUIT
                    }
                ];
                R.address= [ {
                    "line": [ record.DOMICILIO ],
                    "city": record.LOCALIDAD,
                    "postalCode": record.CODiGO_POSTAL,
                    "state": record.PROVINCIA
                  } ];
                if (record.TELEFONO!='')
                {
                  R.telecom=[
                    {
                        system:"phone",
                        value:record.TELEFONO
                    }
                ];
                }
                result.push(R);
            });

            let entries = result.map(organization =>
                new BundleEntry({
                    fullUrl: urlbase+'/fhir/4_0_0/Organization/' + organization.id,
                    resource: organization
                }));
            let bundle = new Bundle({
                id: uuidv4(),
                meta: {
                    lastUpdated: new Date()
                },
                type: "searchset",
                total: entries.length,
                entry: entries
            });
            resolve(bundle);

        }
    )

});

module.exports.searchById = (args, context, logger) => new Promise((resolve, reject) => {
    //	logger.info('Location >>> searchById');

    let { base_version, id } = args;
    var sp = require('./spconfig.js').sp;

    // TODO: Query database q
    sequelize.query(sp("ClienteBuscarPorId"), {
        replacements: { idp: id },
        type: sequelize.QueryTypes.SELECT
    }).then(
        result => {
            // Cast result to Location Class
            let R = new getOrganization();
            //TRAE UN SOLO REGISTRO	
            let record = result[0];

            R.id = record.SECTOR_INTER_ID;
            R.name = record.DESCRIPCION;
            R.identifier = [{
                    system: 'http://www.labdl.com.ar/sector_id',
                    value: record.SECTOR_INTER_ID
                },
                {
                    system: 'http://www.labdl.com.ar/sector_cod',
                    value: record.SEC_COD_EXT
                }
            ];
            // Return resource class
            // resolve(Location_resource);
            resolve(R);

        }
    )

});