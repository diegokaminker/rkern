/*eslint no-unused-vars: "warn"*/
Sequelize = require('sequelize');
const uuidv4 = require('uuid/v4');
const sequelize = require('./dbconfig.js').db;
const sp = require('./spconfig.js').sp;
const { RESOURCES } = require('@asymmetrik/node-fhir-server-core').constants;
const FHIRServer = require('@asymmetrik/node-fhir-server-core');
const getDocumentReference = require('@asymmetrik/node-fhir-server-core/src/server/resources/4_0_0/schemas/documentreference');
const getBundleEntry = require('@asymmetrik/node-fhir-server-core/src/server/resources/4_0_0/schemas/bundleentry');
const getBundle = require('@asymmetrik/node-fhir-server-core/src/server/resources/4_0_0/schemas/bundle');
const urlbase = require('./config.js').urlbase;
let getMeta = (base_version) => {
    return require(FHIRServer.resolveFromVersion(base_version, RESOURCES.META));
};

module.exports.create = (args, context, logger) => new Promise((resolve, reject) => {
    let { base_version, id, resource } = args;
    resource = context.req.body;
    console.log(JSON.stringify(resource));
    let rg = resource;
        console.log("uno");
    var oCod=rg.category[0].coding[0].code;
    console.log("dos");
    console.log(oCod);
    var oTex=rg.content[0].attachment.data;
    console.log("tres");
    console.log(oTex);
    var oFor=rg.content[0].attachment.contentType;
    console.log("cuat");
    console.log(oFor);
    var oRef=rg.context.related[0].reference;
    console.log(oRef);
    console.log("cin");
    var oCom=rg.description;
    console.log("sei");
    console.log(oCom);
    query = sp("DocumentoAdjuntoAgregar");
    param = {
        replacements: {
             cod: oCod,tex:oTex, ref:oRef, com:oCom,xfor:oFor
            },
        type: sequelize.QueryTypes.SELECT
    }
    sequelize.query(query, param).then(
        data => {
            console.log(JSON.stringify(data));
            resolve({ id: data[0].ID });
        });


    // Return Id

});

module.exports.update = (args, context, logger) => new Promise((resolve, reject) => {
    logger.info('RequestGroup >>> update');

    let { base_version, id, resource } = args;

    let RequestGroup = getRequestGroup(base_version);
    let Meta = getMeta(base_version);

    // Cast resource to RequestGroup Class
    let requestgroup_resource = new RequestGroup(resource);
    requestgroup_resource.meta = new Meta();
    // TODO: set meta info, increment meta ID

    // TODO: save record to database

    // Return id, if recorded was created or updated, new meta version id
    resolve({ id: requestgroup_resource.id, created: false, resource_version: requestgroup_resource.meta.versionId });
});