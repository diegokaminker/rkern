var gconfig = require('./config.json');
const urlbase = gconfig.baseurl;
module.exports.urlbase = urlbase;
