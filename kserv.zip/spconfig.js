function sp_get_for(whichcode) {
    var spconfig = require('./spconfig.json');
    var aux = spconfig.procedures.filter(function(item) { return item.code == whichcode; });
    console.log('Buscando');
    console.log(whichcode);
    return aux[0].procedure;
}
module.exports.sp = sp_get_for;