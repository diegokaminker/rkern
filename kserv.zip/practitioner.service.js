/*eslint no-unused-vars: "warn"*/
Sequelize = require('sequelize');
const uuidv4 = require('uuid/v4');
const sp = require('./spconfig.js').sp;
const sequelize = require('./dbconfig.js').db;
const urlbase = require('./config.js').urlbase;
const { RESOURCES } = require('@asymmetrik/node-fhir-server-core').constants;
const FHIRServer = require('@asymmetrik/node-fhir-server-core');
const getPractitioner = require('@asymmetrik/node-fhir-server-core/src/server/resources/4_0_0/schemas/practitioner');
const getBundle = require('@asymmetrik/node-fhir-server-core/src/server/resources/4_0_0/schemas/bundle');
const getBundleEntry = require('@asymmetrik/node-fhir-server-core/src/server/resources/4_0_0/schemas/bundleentry');
let getMeta = (base_version) => {
    return require(FHIRServer.resolveFromVersion(base_version, RESOURCES.META));
};

module.exports.search = (args, context, logger) => new Promise((resolve, reject) => {
    //	logger.info('Practitioner >>> search');

    // Common search params
    let { base_version, _content, _format, _id, _lastUpdated, _profile, _query, _security, _tag } = args;

    // Search Result params
    let { _INCLUDE, _REVINCLUDE, _SORT, _COUNT, _SUMMARY, _ELEMENTS, _CONTAINED, _CONTAINEDTYPED } = args;

    let name = args['name'];
    let iden = args['identifier'];
    // Resource Specific params


    // TODO: Build query from Parameters

    // TODO: Query database
    var query = '';
    var param = {};
    if (!iden) {
        query = sp("MedicoBuscarPorApellido");
        param = {
            replacements: { nam: name + '%' },
            type: sequelize.QueryTypes.SELECT
        }
    } else {
        query = sp("MedicoBuscarPorMatricula");

        param = {
            replacements: { mat: iden },
            type: sequelize.QueryTypes.SELECT
        }
    }

    sequelize.query(query, param).then(
        data => {

            //TRAE UN SOLO REGISTRO	
            var result = [];
            let BundleEntry = getBundleEntry;
            let Bundle = getBundle;
            data.forEach(record => {
                let R = new getPractitioner();
                R.id = record.MEDICO_ID;
                R.name = {
                    family: record.APELLIDO,
                    given: [ record.NOMBRE ],
                    text: [record.APELLIDO+','+record.NOMBRE]
                };
                R.identifier = [{
                        system:  urlbase+'/matricula',
                        value: record.MATRICULA
                    },
                    {
                        system: urlbase+'/lis_medico_id',
                        value: record.MEDICO_ID
                    }
                ];
                R.address= [ {
                    "line": [ record.DIRECCION ],
                    "city": record.LOCALIDAD,
                    "postalCode": record.COD_POS,
                    
                  } ];
                
                  R.telecom=[
                    {
                        system:"phone",
                        value:record.TELEFONO
                    },
                    {
                        system:"email",
                        value:record.EMAIL
                    },
                    
                  ];
              
                result.push(R);
            });

            let entries = result.map(practitioner =>
                new BundleEntry({
                    fullUrl: urlbase+'/fhir/4_0_0/Practitioner/' + practitioner.id,
                    resource: practitioner
                }));
            let bundle = new Bundle({
                id: uuidv4(),
                meta: {
                    lastUpdated: new Date()
                },
                type: "searchset",
                total: entries.length,
                entry: entries
            });
            resolve(bundle);

        }
    )

});

module.exports.searchById = (args, context, logger) => new Promise((resolve, reject) => {
    //	logger.info('Practitioner >>> searchById');

    let { base_version, id } = args;

    // TODO: Query database q
    const query = sp("MedicoBuscarPorId");

    sequelize.query(query, {
        replacements: { idp: id },
        type: sequelize.QueryTypes.SELECT
    }).then(
        result => {
            let R = new getPractitioner();
            //TRAE UN SOLO REGISTRO	
            let record = result[0];

            R.id = record.MEDICO_ID;
            R.name = {
                text: [record.APELLIDO]
            };
            R.identifier = [{
                    system: 'http://www.labdl.com.ar/lis_matricula',
                    value: record.MATRICULA
                },
                {
                    system: 'http://www.labdl.com.ar/lis_medico_id',
                    value: record.MEDICO_ID
                }
            ];
            // Return resource class
            resolve(R);

        }
    )

});