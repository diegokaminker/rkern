var Sequelize = require('sequelize');
var config = require('./dbconfig.json');
const sequelize = new Sequelize(config.dbname, config.uid, config.pwd,
    config.options);
module.exports.db = sequelize;
